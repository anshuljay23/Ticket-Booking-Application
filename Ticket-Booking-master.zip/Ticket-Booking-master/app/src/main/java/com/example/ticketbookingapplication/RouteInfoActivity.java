package com.example.ticketbookingapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RouteInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_info);
    }
}
